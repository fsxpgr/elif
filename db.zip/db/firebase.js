var admin = require("firebase-admin");
var serviceAccount = require("./../test-a2eee-firebase-adminsdk-tpgbd-c196e83f43.json");
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://test-a2eee.firebaseio.com"
});
var db = admin.database();
var ref = db.ref("companies");

var getCompanies = (callback) => {
    ref.on("value",(snap)=>{
        if (snap.val() == null) {
            return callback(null,0);
        } else {
            return callback(snap.val(),snap.val().length);
        }
    }, (err) => {
        return callback(err.code);
    })
};

var addCompany = (name,cash) => {
    getCompanies((e,c)=>{
        if (c==0) {
            return ref.set([{
                    id:0,
                    name:name,
                    cash:cash,
                    more_cash:null,
                    parent_id:null
                }]);
        } else {
            var array =[];
            for(var i = 0;i<c;i++) {
                array.push({
                    id:i,
                    name:e[i].name,
                    cash:e[i].cash,
                    more_cash:null,
                    parent_id:null
            });   
            }
            array.push({
                    id:c,
                    name:name,
                    cash:cash,
                    more_cash:null,
                    parent_id:null
            })
            return ref.set(array);
        }
    })
    
}

module.exports.getCompanies = getCompanies;
module.exports.addCompany = addCompany;