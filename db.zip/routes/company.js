var express = require('express');
var router = express.Router();
var db = require('./../db/firebase');

router.get('/',(req,res,next)=>{
    res.render("company");
})

router.post('/new',(req,res,next)=>{
    db.addCompany(req.body.name,req.body.cash);
    res.redirect('/');
})

module.exports = router;