var express = require('express');
var router = express.Router();
var db = require('./../db/firebase');

/* GET home page. */
router.get('/', (req, res, next) => {
  db.getCompanies((e,count)=>{
    res.render('index', { companies: e });
  })
});

module.exports = router;
